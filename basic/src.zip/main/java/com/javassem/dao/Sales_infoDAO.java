package com.javassem.dao;

import java.util.List;

import com.javassem.domain.BoardVO;
import com.javassem.domain.Sales_infoVO;

public interface Sales_infoDAO {
	public void insertSales_info(Sales_infoVO vo);

	public void updateSales_info(Sales_infoVO vo) ;

	public void deleteSales_info(Sales_infoVO vo);

	public Sales_infoVO getSales_info(Sales_infoVO vo) ;

	public List<Sales_infoVO> getSales_infoList(Sales_infoVO vo) ;
}
