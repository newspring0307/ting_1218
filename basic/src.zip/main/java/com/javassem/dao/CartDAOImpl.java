package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.domain.CartVO;
import com.javassem.domain.CartVO;

@Repository("cartDAO")
public class CartDAOImpl implements CartDAO{

	@Autowired
	private SqlSessionTemplate mybatis;

	public void insertCart(CartVO vo) {
		System.out.println("===> Mybatis insertCart() 호출");
		mybatis.insert("CartDAO.insertCart", vo);
	}

	public void updateCart(CartVO vo) {
		System.out.println("===> Mybatis updateCart() 호출");
		mybatis.update("CartDAO.updateCart", vo);
	}

	public void deleteCart(CartVO vo) {
		System.out.println("===> Mybatis deleteCart() 호출");
		mybatis.delete("CartDAO.deleteCart", vo);
	}

	public CartVO getCart(CartVO vo) {
		System.out.println("===> Mybatis getCart() 호출");
		return mybatis.selectOne("CartDAO.getCart", vo);
	}

	public List<CartVO> getCartList(CartVO vo) {
		System.out.println("===> Mybatis getCartList() 호출");
		return mybatis.selectList("CartDAO.getCartList", vo);
	}
}