package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.domain.Client_infoVO;
import com.javassem.domain.Client_infoVO;

@Repository("client_infoDAO")
public class Client_infoDAOImpl implements Client_infoDAO{

	@Autowired
	private SqlSessionTemplate mybatis;

	public void insertClient_info(Client_infoVO vo) {
		System.out.println("===> Mybatis insertClient_info() 호출");
		mybatis.insert("Client_infoDAO.insertClient_info", vo);
	}

	public void updateClient_info(Client_infoVO vo) {
		System.out.println("===> Mybatis updateClient_info() 호출");
		mybatis.update("Client_infoDAO.updateClient_info", vo);
	}

	public void deleteClient_info(Client_infoVO vo) {
		System.out.println("===> Mybatis deleteClient_info() 호출");
		mybatis.delete("Client_infoDAO.deleteClient_info", vo);
	}

	public Client_infoVO getClient_info(Client_infoVO vo) {
		System.out.println("===> Mybatis getClient_info() 호출");
		return mybatis.selectOne("Client_infoDAO.getClient_info", vo);
	}

	public List<Client_infoVO> getClient_infoList(Client_infoVO vo) {
		System.out.println("===> Mybatis getClient_infoList() 호출");
		return mybatis.selectList("Client_infoDAO.getClient_infoList", vo);
	}
}