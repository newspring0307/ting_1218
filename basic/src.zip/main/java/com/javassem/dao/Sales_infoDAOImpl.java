package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.domain.Sales_infoVO;
import com.javassem.domain.Sales_infoVO;

@Repository("sales_infoDAO")
public class Sales_infoDAOImpl implements Sales_infoDAO{

	@Autowired
	private SqlSessionTemplate mybatis;

	public void insertSales_info(Sales_infoVO vo) {
		System.out.println("===> Mybatis insertSales_info() 호출");
		mybatis.insert("Sales_infoDAO.insertSales_info", vo);
	}

	public void updateSales_info(Sales_infoVO vo) {
		System.out.println("===> Mybatis updateSales_info() 호출");
		mybatis.update("Sales_infoDAO.updateSales_info", vo);
	}

	public void deleteSales_info(Sales_infoVO vo) {
		System.out.println("===> Mybatis deleteSales_info() 호출");
		mybatis.delete("Sales_infoDAO.deleteSales_info", vo);
	}

	public Sales_infoVO getSales_info(Sales_infoVO vo) {
		System.out.println("===> Mybatis getSales_info() 호출");
		return mybatis.selectOne("Sales_infoDAO.getSales_info", vo);
	}

	public List<Sales_infoVO> getSales_infoList(Sales_infoVO vo) {
		System.out.println("===> Mybatis getSales_infoList() 호출");
		return mybatis.selectList("Sales_infoDAO.getSales_infoList", vo);
	}
}