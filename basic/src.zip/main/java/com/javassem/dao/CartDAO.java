package com.javassem.dao;

import java.util.List;

import com.javassem.domain.BoardVO;
import com.javassem.domain.CartVO;

public interface CartDAO {
	public void insertCart(CartVO vo);

	public void updateCart(CartVO vo) ;

	public void deleteCart(CartVO vo);

	public CartVO getCart(CartVO vo) ;

	public List<CartVO> getCartList(CartVO vo) ;
}
