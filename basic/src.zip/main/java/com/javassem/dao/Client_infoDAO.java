package com.javassem.dao;

import java.util.List;

import com.javassem.domain.BoardVO;
import com.javassem.domain.Client_infoVO;

public interface Client_infoDAO {
	public void insertClient_info(Client_infoVO vo);

	public void updateClient_info(Client_infoVO vo) ;

	public void deleteClient_info(Client_infoVO vo);

	public Client_infoVO getClient_info(Client_infoVO vo) ;

	public List<Client_infoVO> getClient_infoList(Client_infoVO vo) ;
}
