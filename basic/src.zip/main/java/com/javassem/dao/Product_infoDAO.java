package com.javassem.dao;

import java.util.List;

import com.javassem.domain.BoardVO;
import com.javassem.domain.Product_infoVO;

public interface Product_infoDAO {
	public void insertProduct_info(Product_infoVO vo);

	public void updateProduct_info(Product_infoVO vo) ;

	public void deleteProduct_info(Product_infoVO vo);

	public Product_infoVO getProduct_info(Product_infoVO vo) ;

	public List<Product_infoVO> getProduct_infoList(Product_infoVO vo) ;
}
