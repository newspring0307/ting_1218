package com.javassem.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.javassem.domain.Product_infoVO;
import com.javassem.domain.Product_infoVO;

@Repository("product_infoDAO")
public class Product_infoDAOImpl implements Product_infoDAO{

	@Autowired
	private SqlSessionTemplate mybatis;

	public void insertProduct_info(Product_infoVO vo) {
		System.out.println("===> Mybatis insertProduct_info() 호출");
		mybatis.insert("Product_infoDAO.insertProduct_info", vo);
	}

	public void updateProduct_info(Product_infoVO vo) {
		System.out.println("===> Mybatis updateProduct_info() 호출");
		mybatis.update("Product_infoDAO.updateProduct_info", vo);
	}

	public void deleteProduct_info(Product_infoVO vo) {
		System.out.println("===> Mybatis deleteProduct_info() 호출");
		mybatis.delete("Product_infoDAO.deleteProduct_info", vo);
	}

	public Product_infoVO getProduct_info(Product_infoVO vo) {
		System.out.println("===> Mybatis getProduct_info() 호출");
		return mybatis.selectOne("Product_infoDAO.getProduct_info", vo);
	}

	public List<Product_infoVO> getProduct_infoList(Product_infoVO vo) {
		System.out.println("===> Mybatis getProduct_infoList() 호출");
		return mybatis.selectList("Product_infoDAO.getProduct_infoList", vo);
	}
}