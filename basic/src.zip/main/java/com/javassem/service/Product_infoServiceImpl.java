package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.BoardDAOImpl;
import com.javassem.dao.Product_infoDAOImpl;
import com.javassem.domain.BoardVO;
import com.javassem.domain.Product_infoVO;


@Service("product_infoService")
public class Product_infoServiceImpl implements Product_infoService {
	
	@Autowired //@Resources
	private Product_infoDAOImpl product_infoDAO;

	public void insertProduct_info(Product_infoVO vo) {

		product_infoDAO.insertProduct_info(vo);;
	}

	public void updateProduct_info(Product_infoVO vo) {
		product_infoDAO.updateProduct_info(vo);
	}

	public void deleteProduct_info(Product_infoVO vo) {
		product_infoDAO.deleteProduct_info(vo);
	}

	public Product_infoVO getProduct_info(Product_infoVO vo) {
		return product_infoDAO.getProduct_info(vo);
	}

	public List<Product_infoVO> getProduct_infoList(Product_infoVO vo) {
		return product_infoDAO.getProduct_infoList(vo);
	}
}