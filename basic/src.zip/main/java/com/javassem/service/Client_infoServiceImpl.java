package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.BoardDAOImpl;
import com.javassem.dao.Client_infoDAOImpl;
import com.javassem.domain.BoardVO;
import com.javassem.domain.Client_infoVO;


@Service("client_infoService")
public class Client_infoServiceImpl implements Client_infoService {
	
	@Autowired //@Resources
	private Client_infoDAOImpl client_infoDAO;

	public void insertClient_info(Client_infoVO vo) {

		client_infoDAO.insertClient_info(vo);;
	}

	public void updateClient_info(Client_infoVO vo) {
		client_infoDAO.updateClient_info(vo);
	}

	public void deleteClient_info(Client_infoVO vo) {
		client_infoDAO.deleteClient_info(vo);
	}

	public Client_infoVO getClient_info(Client_infoVO vo) {
		return client_infoDAO.getClient_info(vo);
	}

	public List<Client_infoVO> getClient_infoList(Client_infoVO vo) {
		return client_infoDAO.getClient_infoList(vo);
	}
}