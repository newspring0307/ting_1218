package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.BoardDAOImpl;
import com.javassem.dao.Sales_infoDAOImpl;
import com.javassem.domain.BoardVO;
import com.javassem.domain.Sales_infoVO;


@Service("sales_infoService")
public class Sales_infoServiceImpl implements Sales_infoService {
	
	@Autowired //@Resources
	private Sales_infoDAOImpl sales_infoDAO;

	public void insertSales_info(Sales_infoVO vo) {

		sales_infoDAO.insertSales_info(vo);;
	}

	public void updateSales_info(Sales_infoVO vo) {
		sales_infoDAO.updateSales_info(vo);
	}

	public void deleteSales_info(Sales_infoVO vo) {
		sales_infoDAO.deleteSales_info(vo);
	}

	public Sales_infoVO getSales_info(Sales_infoVO vo) {
		return sales_infoDAO.getSales_info(vo);
	}

	public List<Sales_infoVO> getSales_infoList(Sales_infoVO vo) {
		return sales_infoDAO.getSales_infoList(vo);
	}
}