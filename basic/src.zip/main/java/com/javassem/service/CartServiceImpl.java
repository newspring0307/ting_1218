package com.javassem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.BoardDAOImpl;
import com.javassem.dao.CartDAOImpl;
import com.javassem.domain.BoardVO;
import com.javassem.domain.CartVO;


@Service("cartService")
public class CartServiceImpl implements CartService {
	
	@Autowired //@Resources
	private CartDAOImpl cartDAO;

	public void insertCart(CartVO vo) {

		cartDAO.insertCart(vo);;
	}

	public void updateCart(CartVO vo) {
		cartDAO.updateCart(vo);
	}

	public void deleteCart(CartVO vo) {
		cartDAO.deleteCart(vo);
	}

	public CartVO getCart(CartVO vo) {
		return cartDAO.getCart(vo);
	}

	public List<CartVO> getCartList(CartVO vo) {
		return cartDAO.getCartList(vo);
	}
}