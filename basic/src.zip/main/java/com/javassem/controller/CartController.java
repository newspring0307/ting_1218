package com.javassem.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.domain.CartVO;
import com.javassem.domain.CartVO;
import com.javassem.service.CartService;

@Controller
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	
	@RequestMapping("/getCartList.do")
	public void getCartList(CartVO vo, Model m) {
		//CartVO vo: 이전화면에서 넘어오는 파라미터 저장(현재는 데이터 없음)
		m.addAttribute("cartList", cartService.getCartList(vo));
	}
	
	@RequestMapping("/{step}.do")
	public String viewPage(@PathVariable String step) {
		return step;
	}
	
	@RequestMapping("/saveCart.do")
	public String saveCart(CartVO vo, Model m) {
		cartService.insertCart(vo);
		//return "cartList"; //단순하게 cartList.jsp 파일로 출력
		return "redirect:/getCartList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/updateCart.do")
	public String updateCart(CartVO vo, Model m) {
		cartService.updateCart(vo);;
		//return "cartList"; //단순하게 cartList.jsp 파일로 출력
		return "redirect:/getCartList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/deleteCart.do")
	public String deleteCart(CartVO vo, Model m) {
		cartService.deleteCart(vo);
		//return "cartList"; //단순하게 cartList.jsp 파일로 출력
		return "redirect:/getCartList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/getCart.do")
	public void getCart(CartVO vo,Model m) {
		CartVO result = cartService.getCart(vo);
		m.addAttribute("cart", result);
	}

}
