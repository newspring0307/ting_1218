package com.javassem.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.domain.Sales_infoVO;
import com.javassem.domain.Sales_infoVO;
import com.javassem.service.Sales_infoService;

@Controller
public class Sales_infoController {
	
	@Autowired
	private Sales_infoService sales_infoService;
	
	
	@RequestMapping("/getSales_infoList.do")
	public void getSales_infoList(Sales_infoVO vo, Model m) {
		//Sales_infoVO vo: 이전화면에서 넘어오는 파라미터 저장(현재는 데이터 없음)
		m.addAttribute("sales_infoList", sales_infoService.getSales_infoList(vo));
	}
	
	@RequestMapping("/{step}.do")
	public String viewPage(@PathVariable String step) {
		return step;
	}
	
	@RequestMapping("/saveSales_info.do")
	public String saveSales_info(Sales_infoVO vo, Model m) {
		sales_infoService.insertSales_info(vo);
		//return "sales_infoList"; //단순하게 sales_infoList.jsp 파일로 출력
		return "redirect:/getSales_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/updateSales_info.do")
	public String updateSales_info(Sales_infoVO vo, Model m) {
		sales_infoService.updateSales_info(vo);;
		//return "sales_infoList"; //단순하게 sales_infoList.jsp 파일로 출력
		return "redirect:/getSales_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/deleteSales_info.do")
	public String deleteSales_info(Sales_infoVO vo, Model m) {
		sales_infoService.deleteSales_info(vo);
		//return "sales_infoList"; //단순하게 sales_infoList.jsp 파일로 출력
		return "redirect:/getSales_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/getSales_info.do")
	public void getSales_info(Sales_infoVO vo,Model m) {
		Sales_infoVO result = sales_infoService.getSales_info(vo);
		m.addAttribute("sales_info", result);
	}

}
