package com.javassem.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.domain.Client_infoVO;
import com.javassem.domain.Client_infoVO;
import com.javassem.service.Client_infoService;

@Controller
public class Client_infoController {
	
	@Autowired
	private Client_infoService client_infoService;
	
	
	@RequestMapping("/getClient_infoList.do")
	public void getClient_infoList(Client_infoVO vo, Model m) {
		//Client_infoVO vo: 이전화면에서 넘어오는 파라미터 저장(현재는 데이터 없음)
		m.addAttribute("client_infoList", client_infoService.getClient_infoList(vo));
	}
	
	@RequestMapping("/{step}.do")
	public String viewPage(@PathVariable String step) {
		return step;
	}
	
	@RequestMapping("/saveClient_info.do")
	public String saveClient_info(Client_infoVO vo, Model m) {
		client_infoService.insertClient_info(vo);
		//return "client_infoList"; //단순하게 client_infoList.jsp 파일로 출력
		return "redirect:/getClient_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/updateClient_info.do")
	public String updateClient_info(Client_infoVO vo, Model m) {
		client_infoService.updateClient_info(vo);;
		//return "client_infoList"; //단순하게 client_infoList.jsp 파일로 출력
		return "redirect:/getClient_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/deleteClient_info.do")
	public String deleteClient_info(Client_infoVO vo, Model m) {
		client_infoService.deleteClient_info(vo);
		//return "client_infoList"; //단순하게 client_infoList.jsp 파일로 출력
		return "redirect:/getClient_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/getClient_info.do")
	public void getClient_info(Client_infoVO vo,Model m) {
		Client_infoVO result = client_infoService.getClient_info(vo);
		m.addAttribute("client_info", result);
	}

}
