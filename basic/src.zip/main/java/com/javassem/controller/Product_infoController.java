package com.javassem.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.domain.Product_infoVO;
import com.javassem.domain.Product_infoVO;
import com.javassem.service.Product_infoService;

@Controller
public class Product_infoController {
	
	@Autowired
	private Product_infoService product_infoService;
	
	
	@RequestMapping("/getProduct_infoList.do")
	public void getProduct_infoList(Product_infoVO vo, Model m) {
		//Product_infoVO vo: 이전화면에서 넘어오는 파라미터 저장(현재는 데이터 없음)
		m.addAttribute("product_infoList", product_infoService.getProduct_infoList(vo));
	}
	
	@RequestMapping("/{step}.do")
	public String viewPage(@PathVariable String step) {
		return step;
	}
	
	@RequestMapping("/saveProduct_info.do")
	public String saveProduct_info(Product_infoVO vo, Model m) {
		product_infoService.insertProduct_info(vo);
		//return "product_infoList"; //단순하게 product_infoList.jsp 파일로 출력
		return "redirect:/getProduct_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/updateProduct_info.do")
	public String updateProduct_info(Product_infoVO vo, Model m) {
		product_infoService.updateProduct_info(vo);;
		//return "product_infoList"; //단순하게 product_infoList.jsp 파일로 출력
		return "redirect:/getProduct_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/deleteProduct_info.do")
	public String deleteProduct_info(Product_infoVO vo, Model m) {
		product_infoService.deleteProduct_info(vo);
		//return "product_infoList"; //단순하게 product_infoList.jsp 파일로 출력
		return "redirect:/getProduct_infoList.do"; //->사용자 url을 변경시킴
	}
	
	@RequestMapping("/getProduct_info.do")
	public void getProduct_info(Product_infoVO vo,Model m) {
		Product_infoVO result = product_infoService.getProduct_info(vo);
		m.addAttribute("product_info", result);
	}

}
