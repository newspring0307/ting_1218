package com.javassem.domain;

import java.util.Date;

//VO(Value Object) : 테이블구조와 유사

public class Sales_infoVO {

	private int sales_id;
	private String client_id;
	private int product_id;
	private Date when;
	private int how_many;
	private String card_or_cash;
	public int getSales_id() {
		return sales_id;
	}
	public void setSales_id(int sales_id) {
		this.sales_id = sales_id;
	}
	public String getClient_id() {
		return client_id;
	}
	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public Date getWhen() {
		return when;
	}
	public void setWhen(Date when) {
		this.when = when;
	}
	public int getHow_many() {
		return how_many;
	}
	public void setHow_many(int how_many) {
		this.how_many = how_many;
	}
	public String getCard_or_cash() {
		return card_or_cash;
	}
	public void setCard_or_cash(String card_or_cash) {
		this.card_or_cash = card_or_cash;
	}

	


}