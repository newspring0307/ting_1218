package com.javassem.domain;

import java.util.Date;

//VO(Value Object) : 테이블구조와 유사

public class Product_infoVO {

	private int product_id;
	private String product_name;
	private int category_gender_id;
	private int category_type_id;
	private int buy_price;
	private int sell_price;
	private String product_info;
	private int stock;
	private String buy_place;
	
	



	

	public int getProduct_id() {
		return product_id;
	}







	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}







	public String getProduct_name() {
		return product_name;
	}







	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}







	public int getCategory_gender_id() {
		return category_gender_id;
	}







	public void setCategory_gender_id(int category_gender_id) {
		this.category_gender_id = category_gender_id;
	}







	public int getCategory_type_id() {
		return category_type_id;
	}







	public void setCategory_type_id(int category_type_id) {
		this.category_type_id = category_type_id;
	}







	public int getBuy_price() {
		return buy_price;
	}







	public void setBuy_price(int buy_price) {
		this.buy_price = buy_price;
	}







	public int getSell_price() {
		return sell_price;
	}







	public void setSell_price(int sell_price) {
		this.sell_price = sell_price;
	}







	public String getProduct_info() {
		return product_info;
	}







	public void setProduct_info(String product_info) {
		this.product_info = product_info;
	}







	public int getStock() {
		return stock;
	}







	public void setStock(int stock) {
		this.stock = stock;
	}







	public String getBuy_place() {
		return buy_place;
	}







	public void setBuy_place(String buy_place) {
		this.buy_place = buy_place;
	}


}