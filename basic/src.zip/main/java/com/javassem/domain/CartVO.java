package com.javassem.domain;

import java.util.Date;

//VO(Value Object) : 테이블구조와 유사

public class CartVO {

	private int cart_id;
	private String client_id;
	private int product_id;
	private int how_many;
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public String getClient_id() {
		return client_id;
	}
	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public int getHow_many() {
		return how_many;
	}
	public void setHow_many(int how_many) {
		this.how_many = how_many;
	}
	
	
	

	


}