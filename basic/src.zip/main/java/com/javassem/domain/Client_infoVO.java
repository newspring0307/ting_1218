package com.javassem.domain;

import java.util.Date;

//VO(Value Object) : 테이블구조와 유사

public class Client_infoVO {


	
	public String getClient_id() {
		return client_id;
	}




	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}




	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}




	public String getClient_name() {
		return client_name;
	}




	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}




	public String getAddr() {
		return addr;
	}




	public void setAddr(String addr) {
		this.addr = addr;
	}




	public String getPhone() {
		return phone;
	}




	public void setPhone(String phone) {
		this.phone = phone;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	private String client_id;
	private String password;
	private String client_name;
	private String addr;
	private String phone;
	private String email;


	

	@Override
	public String toString() {
		return "Client_infoVO [client_id=" + client_id + ", password=" + password + ", client_name=" + client_name + ", addr=" + addr + ", phone="
				+ phone + ", email=" + email + "]";
	}
}